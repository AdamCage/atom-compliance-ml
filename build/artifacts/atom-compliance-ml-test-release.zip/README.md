# Контроль и управление изменениями в тендерных закупках

# Структура проекта

```bash
.
├───config
├───data
│   ├───HMI
│   └───SSTS
├───doc
├───eda
├───models
└───src
    ├───modules
    ├───notebooks
    └───scripts
```

